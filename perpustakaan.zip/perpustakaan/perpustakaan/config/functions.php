<?php  //register yang digunakan untuk mendaftarkan pengguna baru ke dalam database
require_once 'koneksi.php';  //Import Koneksi Database

function register($data) {  //Definisi Fungsi register
	global $conn;
	$nama = htmlspecialchars($data['nama']);
	$username = $conn->real_escape_string($data['username']);
	$password = $conn->real_escape_string($data['password']);
	$password2 = $conn->real_escape_string($data['password2']);
	echo $username;
	echo $password;

	// jika username sudah terdaftar
	if($conn->query("SELECT * FROM tb_user WHERE username = '$username'")) {    //Cek Username Terdaftar
		echo "<script>alert('Username sudah terdaftar!');window.location='register.php';</script>";
		return false;
	}

	if($password != $password2) {  //cek Konfirmasi Password
		echo "<script>alert('konfirmasi password salah.');</script>";
		return false;
	}

	if(strlen($username) < 6 ) {   //Cek Panjang Username
		echo "<script>alert('Password terlalu pendek, maksimal 6 digit');window.location='register.php';</script>";
		return false;
	}

	$password = password_hash($password, PASSWORD_DEFAULT);    //Hashing Password dimana Mengenkripsi password menggunakan algoritma hashing default yang aman.
                                                                    //Menyisipkan data pengguna baru ke dalam tabel tb_user
	$conn->query("INSERT INTO tb_user VALUES (null, '$username', '$password', '$nama', '$foto')") or die(mysqli_error($conn));  //Insert Data ke Database:
	return $conn->affected_rows;
}

