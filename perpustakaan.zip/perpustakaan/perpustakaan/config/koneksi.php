<?php //mengatur dan menyediakan koneksi ke database, sehingga aplikasi web
      //dapat berinteraksi dengan database untuk menyimpan, mengambil, memperbarui, atau menghapus data
$conn = new mysqli("localhost", "root", "", "perpustakaan"); //digunakan untuk membuat koneksi ke database MySQL menggunakan objek mysqli dalam PHP

if ($conn->connect_errno) {  //untuk memeriksa apakah terjadi kesalahan saat mencoba membuat koneksi ke database menggunakan objek mysqli dalam PHP
  echo "Koneksi Gagal, silahkan coba lihat DB: " . $conn->connect_error;
  exit();
}

?>